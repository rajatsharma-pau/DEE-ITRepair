<?php $__env->startSection('content'); ?>
<div class="card"><div class="card-header">Add Store Item</div><div class="card-body"><form method="POST" action="<?php echo e(route('store-items.store')); ?>"><?php echo $__env->make('store_items.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></form></div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PAU Mobile Project\dee-it-repair\resources\views/store_items/create.blade.php ENDPATH**/ ?>