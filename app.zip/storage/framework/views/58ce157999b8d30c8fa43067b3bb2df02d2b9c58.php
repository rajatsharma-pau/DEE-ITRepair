<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h4 class="mb-0"><?php echo e($dashboardTitle ?? 'Dashboard'); ?></h4>
        <small class="text-muted"><?php echo e($dashboardSubtitle ?? ''); ?></small>
    </div>
    <div>
        <a href="<?php echo e(route('repair-requests.create')); ?>" class="btn btn-sm btn-success">New Repair Request</a>
        <a href="<?php echo e(route('store-indents.create')); ?>" class="btn btn-sm btn-outline-success">New Indent</a>
    </div>
</div>

<?php if($isEmployeeDashboard ?? false): ?>
    <div class="alert alert-light border mb-3">
        <strong>Employee quick panel:</strong> submit request, see allocated assets, track requests, submit store indent and update profile photo.
    </div>
<?php else: ?>
    <div class="alert alert-light border mb-3">
        <strong>Workflow:</strong> Employee request → Storekeeper vendor estimate/PDF → Programmer or Store Incharge verification → Storekeeper proforma print → Manual D-4 process.
    </div>
<?php endif; ?>

<div class="row">
    <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-sm-4 col-md-3 col-xl-2 mb-3">
            <a class="dashboard-card" href="<?php echo e($card['url']); ?>">
                <div class="card dash-border-<?php echo e($card['class'] ?? 'primary'); ?>">
                    <div class="card-body text-center">
                        <div class="dashboard-card-count"><?php echo e($card['count']); ?></div>
                        <div class="dashboard-card-title"><?php echo e($card['title']); ?></div>
                        <div class="dashboard-card-text"><?php echo e($card['text'] ?? 'Open'); ?></div>
                    </div>
                </div>
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="card shadow-sm">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span><?php echo e(($isEmployeeDashboard ?? false) ? 'My Recent Repair / Material Requests' : 'Recent Repair / Material Requests'); ?></span>
        <a href="<?php echo e(route('repair-requests.index')); ?>" class="btn btn-sm btn-outline-primary">View All</a>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-bordered table-sm mb-0">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Employee</th>
                    <th>Category</th>
                    <th>Vendor/Estimate</th>
                    <th>Status</th>
                    <th>Assigned To</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($r->request_no); ?></td>
                    <td><?php echo e(optional($r->employee)->display_name); ?></td>
                    <td><?php echo e(optional($r->category)->name); ?></td>
                    <td>
                        <?php if($r->selectedEstimate): ?>
                            <?php echo e(optional($r->selectedEstimate->vendor)->name); ?><br>
                            <small>Rs. <?php echo e(number_format($r->selectedEstimate->estimate_amount,2)); ?></small>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td><span class="badge badge-info"><?php echo e($r->status); ?></span></td>
                    <td><?php echo e(optional($r->assignedTo)->display_name ?: '-'); ?></td>
                    <td><a class="btn btn-sm btn-primary" href="<?php echo e(route('repair-requests.show', $r)); ?>">View</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center text-muted">No request found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PAU Mobile Project\dee-it-repair\resources\views/home.blade.php ENDPATH**/ ?>