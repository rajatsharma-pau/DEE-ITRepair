<?php echo csrf_field(); ?>
<div class="row">
<div class="col-md-4 form-group"><label>College / Directorate</label><select id="stock_college_id" name="college_id" class="form-control"><option value="">Select</option><?php $__currentLoopData = $colleges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php echo e(old('college_id',$item->college_id)==$c->id?'selected':''); ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
<div class="col-md-4 form-group"><label>Department / Office / KVK</label><select id="stock_department_id" name="department_id" class="form-control"><option value="">Select</option><?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($d->id); ?>" data-college="<?php echo e($d->college_id); ?>" <?php echo e(old('department_id',$item->department_id)==$d->id?'selected':''); ?>><?php echo e($d->name); ?><?php echo e($d->place ? ' - '.$d->place : ''); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
</div>
<div class="row">
<div class="col-md-3 form-group"><label>Item Code</label><input name="item_code" class="form-control" value="<?php echo e(old('item_code',$item->item_code)); ?>"></div>
<div class="col-md-4 form-group"><label class="required">Item Name</label><input name="name" class="form-control" required value="<?php echo e(old('name',$item->name)); ?>" placeholder="A4 Paper, Pen, File Cover"></div>
<div class="col-md-3 form-group"><label>Category</label><input name="category" class="form-control" value="<?php echo e(old('category',$item->category)); ?>" placeholder="Stationery"></div>
<div class="col-md-2 form-group"><label class="required">Unit</label><input name="unit" class="form-control" required value="<?php echo e(old('unit',$item->unit)); ?>" placeholder="Nos/Ream/Packet"></div>
</div>
<div class="row">
<div class="col-md-3 form-group"><label>Brand</label><input name="brand" class="form-control" value="<?php echo e(old('brand',$item->brand)); ?>"></div>
<?php if(!$item->exists): ?><div class="col-md-3 form-group"><label>Opening Stock</label><input type="number" step="0.01" name="opening_stock" class="form-control" value="<?php echo e(old('opening_stock',$item->opening_stock)); ?>"></div><?php endif; ?>
<div class="col-md-3 form-group"><label>Reorder Level</label><input type="number" step="0.01" name="reorder_level" class="form-control" value="<?php echo e(old('reorder_level',$item->reorder_level)); ?>"></div>
<div class="col-md-3 form-group"><label>Location</label><input name="location" class="form-control" value="<?php echo e(old('location',$item->location)); ?>"></div>
</div>
<div class="form-group"><label>Description</label><textarea name="description" class="form-control"><?php echo e(old('description',$item->description)); ?></textarea></div>
<div class="form-group"><label><input type="checkbox" name="is_active" value="1" <?php echo e(old('is_active',$item->is_active) ? 'checked' : ''); ?>> Active</label></div>
<button class="btn btn-success">Save</button><a href="<?php echo e(route('store-items.index')); ?>" class="btn btn-secondary">Back</a>

<?php $__env->startPush('scripts'); ?>
<script>
function filterStockDepartments(){
 var collegeId = $('#stock_college_id').val();
 $('#stock_department_id option').each(function(){ var optCollege=$(this).data('college'); if(!$(this).val() || !collegeId || optCollege==collegeId){$(this).show();} else {$(this).hide();} });
 var selected=$('#stock_department_id option:selected'); if(collegeId && selected.val() && selected.data('college') != collegeId){ $('#stock_department_id').val(''); }
}
$('#stock_college_id').on('change', filterStockDepartments); filterStockDepartments();
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH E:\PAU Mobile Project\dee-it-repair\resources\views/store_items/form.blade.php ENDPATH**/ ?>