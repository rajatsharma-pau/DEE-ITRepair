<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'DEE IT Repair')); ?></title>

    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        body { background:#f5f6f8; font-size:14px; }
        .dee-topbar { background:#1f7f4c; box-shadow:0 2px 6px rgba(0,0,0,.12); }
        .dee-topbar .navbar-brand { font-weight:700; letter-spacing:.2px; }
        .dee-topbar .nav-link, .dee-topbar .navbar-brand { color:#fff !important; }
        .dee-topbar .nav-link { padding:.45rem .65rem; font-weight:600; }
        .dee-topbar .nav-link:hover, .dee-topbar .dropdown.show > .nav-link { background:rgba(255,255,255,.12); border-radius:4px; }
        .dee-topbar .dropdown-menu { border:0; box-shadow:0 8px 18px rgba(0,0,0,.12); font-size:14px; }
        .dee-topbar .dropdown-item { padding:.55rem 1rem; }
        .dee-avatar { width:32px; height:32px; border-radius:50%; object-fit:cover; border:2px solid rgba(255,255,255,.75); background:#e9ecef; }
        .dee-avatar-placeholder { width:32px; height:32px; border-radius:50%; display:inline-flex; align-items:center; justify-content:center; font-weight:700; background:#e9ecef; color:#1f7f4c; border:2px solid rgba(255,255,255,.75); }
        .dee-user-name { max-width:210px; overflow:hidden; white-space:nowrap; text-overflow:ellipsis; display:inline-block; vertical-align:middle; }
        .dee-workflow { background:#e8f6f0; border-bottom:1px solid #cbeadb; color:#235c43; font-size:13px; padding:8px 15px; }
        .content-wrap { padding:18px 15px; }
        .card { border:0; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,.07); }
        .dashboard-card { display:block; color:#222; text-decoration:none !important; height:100%; }
        .dashboard-card .card-body { padding:14px 12px; min-height:112px; }
        .dashboard-card .card { transition:.12s ease-in-out; border-left:4px solid #1f7f4c; }
        .dashboard-card:hover .card { transform:translateY(-2px); box-shadow:0 5px 16px rgba(0,0,0,.13); }
        .dashboard-card-count { font-size:24px; font-weight:800; line-height:1.1; }
        .dashboard-card-title { font-weight:700; font-size:14px; margin-top:6px; }
        .dashboard-card-text { font-size:12px; color:#6c757d; margin-top:4px; }
        .dash-border-success { border-left-color:#28a745 !important; }
        .dash-border-warning { border-left-color:#ffc107 !important; }
        .dash-border-info { border-left-color:#17a2b8 !important; }
        .dash-border-primary { border-left-color:#007bff !important; }
        .dash-border-danger { border-left-color:#dc3545 !important; }
        .dash-border-secondary { border-left-color:#6c757d !important; }
        .dash-border-dark { border-left-color:#343a40 !important; }
        @media (max-width: 991.98px) {
            .dee-user-name { max-width:100%; }
            .dee-topbar .navbar-nav.ml-auto { margin-top:8px; }
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
<div id="app">
    <?php if(auth()->guard()->check()): ?>
        <?php
            $user = Auth::user();

            /* Safe role helpers so this layout does not break if old User model is still present. */
            $roleNames = array();
            if ($user && method_exists($user, 'roleNames')) {
                try {
                    $roleNames = $user->roleNames();
                    if ($roleNames instanceof \Illuminate\Support\Collection) {
                        $roleNames = $roleNames->toArray();
                    }
                    $roleNames = array_values(array_filter((array) $roleNames));
                } catch (\Exception $e) {
                    $roleNames = array();
                }
            }
            if (empty($roleNames) && $user && isset($user->roles)) {
                try {
                    $rolesCollection = $user->roles;
                    if ($rolesCollection instanceof \Illuminate\Support\Collection) {
                        $roleNames = $rolesCollection->map(function ($role) {
                            return isset($role->slug) && $role->slug ? $role->slug : (isset($role->name) ? $role->name : null);
                        })->filter()->values()->toArray();
                    }
                } catch (\Exception $e) {
                    $roleNames = array();
                }
            }
            if (empty($roleNames) && $user && isset($user->role) && $user->role) {
                $roleNames = array($user->role);
            }

            $hasRole = function ($role) use ($user, $roleNames) {
                if (!$user) {
                    return false;
                }
                if (method_exists($user, 'hasRole')) {
                    try {
                        return (bool) $user->hasRole($role);
                    } catch (\Exception $e) {
                        // fallback below
                    }
                }
                return in_array($role, $roleNames);
            };

            $hasAnyRole = function (array $roles) use ($hasRole) {
                foreach ($roles as $role) {
                    if ($hasRole($role)) {
                        return true;
                    }
                }
                return false;
            };

            $employee = null;
            try {
                $employee = method_exists($user, 'employee') ? $user->employee : null;
            } catch (\Exception $e) {
                $employee = null;
            }

            $isSuperuser = $hasRole('superuser');
            $isEmployeeAdmin = $hasAnyRole(array('superuser', 'admin', 'college_admin', 'department_admin', 'director'));

            /* Store visibility and manage permission are intentionally separate. */
            if (class_exists('App\\Support\\StoreAccessScope')) {
                $canViewStore = \App\Support\StoreAccessScope::canViewStore($user);
                $canManageStore = \App\Support\StoreAccessScope::canManageStore($user);
            } else {
                $canViewStore = $hasAnyRole(array('superuser', 'admin', 'college_admin', 'department_admin', 'director', 'storekeeper', 'employee'));
                $canManageStore = $hasAnyRole(array('superuser', 'storekeeper'));
            }

            $canViewStoreRecords = $hasAnyRole(array('superuser', 'admin', 'college_admin', 'department_admin', 'director', 'storekeeper'));
            $canCreateOwnIndent = ($hasRole('employee') && !$hasAnyRole(array('admin', 'college_admin', 'department_admin', 'director'))) || $hasRole('storekeeper') || $isSuperuser;

            $isTechnical = $hasAnyRole(array('superuser', 'programmer')) || ($employee && method_exists($employee, 'hasActiveCharge') && $employee->hasActiveCharge('Store Incharge'));
            $isD4 = $hasAnyRole(array('superuser', 'd4_seat'));

            $role = method_exists($user, 'roleLabel') ? $user->roleLabel() : ucwords(str_replace('_', ' ', implode(', ', $roleNames ?: array('employee'))));

            /* Primary login scope should come from users.college_id / users.department_id first. */
            $deptName = null;
            $collegeName = null;
            try {
                $deptName = optional($user->department)->name;
            } catch (\Exception $e) {
                $deptName = null;
            }
            try {
                $collegeName = optional($user->college)->name;
            } catch (\Exception $e) {
                $collegeName = null;
            }
            if (!$deptName && $employee) {
                try {
                    $deptName = optional($employee->department)->name;
                } catch (\Exception $e) {
                    $deptName = null;
                }
            }
            if (!$collegeName && $employee) {
                try {
                    $collegeName = optional($employee->college)->name;
                } catch (\Exception $e) {
                    $collegeName = null;
                }
            }

            $scopeLabel = $deptName ?: ($collegeName ?: 'Own Records');
            if (class_exists('App\\Support\\AccessScope') && method_exists('App\\Support\\AccessScope', 'scopeLabel')) {
                try {
                    $scopeLabel = \App\Support\AccessScope::scopeLabel($user);
                } catch (\Exception $e) {
                    // keep fallback label
                }
            }
        ?>

        <nav class="navbar navbar-expand-lg navbar-dark dee-topbar">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">DEE IT Repair</a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('home')); ?>">Dashboard</a></li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="requestsMenu" role="button" data-toggle="dropdown">Requests</a>
                        <div class="dropdown-menu" aria-labelledby="requestsMenu">
                            <a class="dropdown-item" href="<?php echo e(route('repair-requests.index')); ?>">All Repair Requests</a>
                            <a class="dropdown-item" href="<?php echo e(route('repair-requests.create')); ?>">New Repair Request</a>

                            <?php if($canManageStore || $isTechnical || $isD4): ?>
                                <div class="dropdown-divider"></div>
                            <?php endif; ?>

                            <?php if($canManageStore): ?>
                                <a class="dropdown-item" href="<?php echo e(route('repair-requests.index', ['handler' => 'storekeeper'])); ?>">Pending with Storekeeper</a>
                            <?php endif; ?>

                            <?php if($isTechnical): ?>
                                <a class="dropdown-item" href="<?php echo e(route('repair-requests.index', ['handler' => 'programmer'])); ?>">Verification Pending</a>
                            <?php endif; ?>

                            <?php if($isD4): ?>
                                <a class="dropdown-item" href="<?php echo e(route('repair-requests.index', ['handler' => 'd4_seat'])); ?>">D-4 Manual Files</a>
                            <?php endif; ?>
                        </div>
                    </li>

                    <?php if($canViewStore || $hasRole('employee')): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="assetsMenu" role="button" data-toggle="dropdown">Assets</a>
                            <div class="dropdown-menu" aria-labelledby="assetsMenu">
                                <a class="dropdown-item" href="<?php echo e(route('assets.index')); ?>">Assets</a>
                                <?php if($canManageStore): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('assets.create')); ?>">Add Asset</a>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endif; ?>

                    <?php if($canViewStoreRecords || $canCreateOwnIndent): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="storeMenu" role="button" data-toggle="dropdown">Store</a>
                            <div class="dropdown-menu" aria-labelledby="storeMenu">
                                <a class="dropdown-item" href="<?php echo e(route('store-indents.index')); ?>">Store Indents</a>

                                <?php if($canCreateOwnIndent): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('store-indents.create')); ?>">New Indent</a>
                                <?php endif; ?>

                                <?php if($canViewStoreRecords): ?>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="<?php echo e(route('store-items.index')); ?>">Store Stock</a>
                                    <a class="dropdown-item" href="<?php echo e(route('store-items.index', ['low_stock' => 1])); ?>">Low Stock Items</a>
                                <?php endif; ?>

                                <?php if($canManageStore): ?>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="<?php echo e(route('store-items.create')); ?>">Add Stock Item</a>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endif; ?>

                    <?php if($isEmployeeAdmin): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="adminMenu" role="button" data-toggle="dropdown">Admin</a>
                            <div class="dropdown-menu" aria-labelledby="adminMenu">
                                <a class="dropdown-item" href="<?php echo e(route('employees.index')); ?>">Employees</a>
                                <a class="dropdown-item" href="<?php echo e(route('employees.create')); ?>">Add Employee</a>

                                <?php if($isSuperuser): ?>
                                    <div class="dropdown-divider"></div>
                                    <?php echo $__env->make('layouts.master_menu_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <a class="dropdown-item" href="<?php echo e(route('masters.vendors')); ?>">Vendors</a>
                                    <a class="dropdown-item" href="<?php echo e(route('masters.problem-templates')); ?>">Problem Templates</a>
                                    <a class="dropdown-item" href="<?php echo e(route('masters.repair-categories')); ?>">Repair Categories</a>
                                    <a class="dropdown-item" href="<?php echo e(route('masters.routing-rules')); ?>">Routing Rules</a>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>

                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="userMenu" role="button" data-toggle="dropdown">
                            <?php if($employee && $employee->photo_url): ?>
                                <img src="<?php echo e($employee->photo_url); ?>" alt="Profile" class="dee-avatar mr-2">
                            <?php else: ?>
                                <span class="dee-avatar-placeholder mr-2"><?php echo e(strtoupper(substr($user->name ?: 'U', 0, 1))); ?></span>
                            <?php endif; ?>
                            <span class="dee-user-name"><?php echo e($user->name ?: 'User'); ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userMenu">
                            <h6 class="dropdown-header">
                                <?php echo e($role); ?><br>
                                <small><?php echo e($scopeLabel); ?></small>
                            </h6>
                            <a class="dropdown-item" href="<?php echo e(route('profile.show')); ?>">My Profile / Photo</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('profile.password.change')); ?>">Change Password</a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display:none;"><?php echo csrf_field(); ?></form>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>

        <div class="dee-workflow">
            <strong>Workflow:</strong> Employee Request → Storekeeper Estimate PDF → Programmer / Store Incharge Verification → Proforma Print → Manual D-4 Process
        </div>
    <?php endif; ?>

    <?php if(auth()->guard()->guest()): ?>
        <nav class="navbar navbar-dark dee-topbar">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">DEE IT Repair</a>
        </nav>
    <?php endif; ?>

    <main class="content-wrap">
        <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
        <?php if(session('error')): ?><div class="alert alert-danger"><?php echo e(session('error')); ?></div><?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
            </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH E:\PAU Mobile Project\dee-it-repair\resources\views/layouts/app.blade.php ENDPATH**/ ?>