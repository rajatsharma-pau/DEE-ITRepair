<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-3">
    <h4>Store Inventory</h4>
    <?php if(Auth::user()->isRole(['admin','college_admin','department_admin','director','storekeeper'])): ?><a href="<?php echo e(route('store-items.create')); ?>" class="btn btn-success">Add Store Item</a><?php endif; ?>
</div>
<div class="card mb-3"><div class="card-body"><form method="GET" class="form-row">
<div class="col-md-3 mb-2"><input name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Search paper, pen, stationery item"></div>
<?php if(Auth::user()->isRole(['admin','college_admin','department_admin','director','storekeeper'])): ?>
<div class="col-md-3 mb-2"><select name="college_id" class="form-control"><option value="">All Colleges/Directorates</option><?php $__currentLoopData = $colleges ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php echo e(request('college_id')==$c->id?'selected':''); ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
<div class="col-md-3 mb-2"><select name="department_id" class="form-control"><option value="">All Departments</option><?php $__currentLoopData = $departments ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($d->id); ?>" <?php echo e(request('department_id')==$d->id?'selected':''); ?>><?php echo e($d->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
<?php endif; ?>
<div class="col-md-2 mb-2"><label><input type="checkbox" name="low_stock" value="1" <?php echo e(request('low_stock')?'checked':''); ?>> Low stock only</label></div>
<div class="col-md-1 mb-2"><button class="btn btn-primary btn-block">Go</button></div>
</form></div></div>
<div class="card"><div class="card-body table-responsive"><table class="table table-bordered table-sm">
<thead><tr><th>Code</th><th>Item</th><th>Category</th><th>Unit</th><th>Current Stock</th><th>Reorder Level</th><th>Status</th><th>Action</th></tr></thead><tbody>
<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
<td><?php echo e($item->item_code); ?></td><td><?php echo e($item->name); ?><br><small><?php echo e($item->brand); ?></small></td><td><?php echo e($item->category); ?></td><td><?php echo e($item->unit); ?></td>
<td><strong><?php echo e($item->current_stock); ?></strong></td><td><?php echo e($item->reorder_level); ?></td>
<td><?php if($item->current_stock <= $item->reorder_level): ?><span class="badge badge-danger">Low Stock</span><?php else: ?><span class="badge badge-success">OK</span><?php endif; ?></td>
<td><a href="<?php echo e(route('store-items.show',$item)); ?>" class="btn btn-sm btn-primary">View</a> <?php if(Auth::user()->isRole(['admin','college_admin','department_admin','director','storekeeper'])): ?><a href="<?php echo e(route('store-items.edit',$item)); ?>" class="btn btn-sm btn-warning">Edit</a><?php endif; ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <tr><td colspan="8">No store item found.</td></tr> <?php endif; ?>
</tbody></table><?php echo e($items->appends(request()->query())->links()); ?></div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PAU Mobile Project\dee-it-repair\resources\views/store_items/index.blade.php ENDPATH**/ ?>