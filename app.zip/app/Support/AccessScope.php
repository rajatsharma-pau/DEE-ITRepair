<?php

namespace App\Support;

class AccessScope
{
    protected static function currentUser($user = null)
    {
        return $user ?: auth()->user();
    }

    protected static function userHasRole($user, $role)
    {
        if (!$user) {
            return false;
        }

        if (method_exists($user, 'hasRole')) {
            return $user->hasRole($role);
        }

        if (isset($user->role) && $user->role === $role) {
            return true;
        }

        if (method_exists($user, 'roleNames')) {
            return in_array($role, $user->roleNames());
        }

        return false;
    }

    protected static function userHasAnyRole($user, array $roles)
    {
        if (!$user) {
            return false;
        }

        if (method_exists($user, 'hasAnyRole')) {
            return $user->hasAnyRole($roles);
        }

        foreach ($roles as $role) {
            if (self::userHasRole($user, $role)) {
                return true;
            }
        }

        return false;
    }

    public static function isSuperuser($user = null)
    {
        $user = self::currentUser($user);
        return self::userHasRole($user, 'superuser');
    }

    public static function isEmployeeOnly($user = null)
    {
        $user = self::currentUser($user);

        if (!$user) {
            return false;
        }

        return !self::userHasAnyRole($user, [
            'superuser',
            'admin',
            'college_admin',
            'department_admin',
            'director',
            'storekeeper',
            'programmer',
            'store_incharge',
            'd4_seat',
        ]);
    }

    public static function collegeId($user = null)
    {
        $user = self::currentUser($user);
        return $user && isset($user->college_id) ? $user->college_id : null;
    }

    public static function departmentId($user = null)
    {
        $user = self::currentUser($user);
        return $user && isset($user->department_id) ? $user->department_id : null;
    }

    public static function college($user = null)
    {
        $collegeId = self::collegeId($user);

        if (!$collegeId || !\Schema::hasTable('colleges')) {
            return null;
        }

        return \DB::table('colleges')->where('id', $collegeId)->first();
    }

    public static function department($user = null)
    {
        $departmentId = self::departmentId($user);

        if (!$departmentId || !\Schema::hasTable('departments')) {
            return null;
        }

        return \DB::table('departments')->where('id', $departmentId)->first();
    }

    public static function apply($query, $collegeColumn = 'college_id', $departmentColumn = 'department_id', $user = null)
    {
        $user = self::currentUser($user);

        if (!$user) {
            return $query->whereRaw('1 = 0');
        }

        if (self::isSuperuser($user)) {
            return $query;
        }

        if (self::userHasRole($user, 'department_admin')) {
            if (self::departmentId($user)) {
                return $query->where($departmentColumn, self::departmentId($user));
            }
            return $query->whereRaw('1 = 0');
        }

        if (self::userHasAnyRole($user, ['admin', 'college_admin', 'director'])) {
            if (self::collegeId($user)) {
                return $query->where($collegeColumn, self::collegeId($user));
            }
            return $query->whereRaw('1 = 0');
        }

        if (self::isEmployeeOnly($user)) {
            if (isset($user->employee) && $user->employee && isset($user->employee->id)) {
                return $query->where('id', $user->employee->id);
            }
            return $query->whereRaw('1 = 0');
        }

        // Functional roles such as storekeeper/programmer should normally be scoped
        // by their own modules. For employee records, keep them within department.
        if (self::departmentId($user)) {
            return $query->where($departmentColumn, self::departmentId($user));
        }

        return $query->whereRaw('1 = 0');
    }

    public static function canAccessCollege($collegeId, $user = null)
    {
        $user = self::currentUser($user);

        if (!$user || !$collegeId) {
            return false;
        }

        if (self::isSuperuser($user)) {
            return true;
        }

        // College Admin/Admin/Director can access only their own college/directorate
        // for employee add/edit and normal master-scope fields.
        if (self::userHasAnyRole($user, ['admin', 'college_admin', 'director', 'department_admin', 'storekeeper'])) {
            return (int) self::collegeId($user) === (int) $collegeId;
        }

        return false;
    }

    public static function canAccessDepartment($departmentId, $user = null)
    {
        $user = self::currentUser($user);

        if (!$user || !$departmentId) {
            return false;
        }

        if (self::isSuperuser($user)) {
            return true;
        }

        if (!\Schema::hasTable('departments')) {
            return false;
        }

        $department = \DB::table('departments')->where('id', $departmentId)->first();

        if (!$department) {
            return false;
        }

        if (self::userHasRole($user, 'department_admin')) {
            return (int) self::departmentId($user) === (int) $departmentId;
        }

        if (self::userHasAnyRole($user, ['admin', 'college_admin', 'director', 'storekeeper'])) {
            return (int) self::collegeId($user) === (int) $department->college_id;
        }

        return false;
    }

    public static function canAccessEmployee($employee, $user = null)
    {
        $user = self::currentUser($user);

        if (!$user || !$employee) {
            return false;
        }

        if (self::isSuperuser($user)) {
            return true;
        }

        if (self::userHasRole($user, 'department_admin')) {
            return isset($employee->department_id) && (int) $employee->department_id === (int) self::departmentId($user);
        }

        if (self::userHasAnyRole($user, ['admin', 'college_admin', 'director'])) {
            return isset($employee->college_id) && (int) $employee->college_id === (int) self::collegeId($user);
        }

        if (self::isEmployeeOnly($user)) {
            return isset($employee->user_id) && (int) $employee->user_id === (int) $user->id;
        }

        return false;
    }

    public static function canEditEmployee($employee, $user = null)
    {
        $user = self::currentUser($user);

        if (!$user || !$employee) {
            return false;
        }

        if (self::isSuperuser($user)) {
            return true;
        }

        if (self::userHasRole($user, 'department_admin')) {
            return isset($employee->department_id) && (int) $employee->department_id === (int) self::departmentId($user);
        }

        if (self::userHasAnyRole($user, ['admin', 'college_admin', 'director'])) {
            return isset($employee->college_id) && (int) $employee->college_id === (int) self::collegeId($user);
        }

        return false;
    }

    public static function canTransferEmployee($employee, $user = null)
    {
        $user = self::currentUser($user);

        if (!$user || !$employee) {
            return false;
        }

        if (self::isSuperuser($user)) {
            return true;
        }

        // Final rule: College Admin/Admin/Director can transfer employees
        // currently belonging to their own college/directorate to any destination.
        if (self::userHasAnyRole($user, ['admin', 'college_admin', 'director'])) {
            return isset($employee->college_id) && (int) $employee->college_id === (int) self::collegeId($user);
        }

        // Final rule: Department Admin can transfer employees currently belonging
        // to own department to any destination.
        if (self::userHasRole($user, 'department_admin')) {
            return isset($employee->department_id) && (int) $employee->department_id === (int) self::departmentId($user);
        }

        return false;
    }

    public static function canAssignRolesToEmployee($employee, $user = null)
    {
        $user = self::currentUser($user);

        if (!$user || !$employee) {
            return false;
        }

        if (self::isSuperuser($user)) {
            return true;
        }

        if (self::userHasAnyRole($user, ['admin', 'college_admin', 'director'])) {
            return isset($employee->college_id) && (int) $employee->college_id === (int) self::collegeId($user);
        }

        if (self::userHasRole($user, 'department_admin')) {
            return isset($employee->department_id) && (int) $employee->department_id === (int) self::departmentId($user);
        }

        return false;
    }

    public static function allowedAssignableRoles($employee = null, $user = null)
    {
        $user = self::currentUser($user);

        if (!$user) {
            return [];
        }

        if (self::isSuperuser($user)) {
            return [
                'superuser',
                'admin',
                'college_admin',
                'department_admin',
                'employee',
                'storekeeper',
                'programmer',
                'store_incharge',
                'd4_seat',
                'director',
            ];
        }

        if ($employee && !self::canAssignRolesToEmployee($employee, $user)) {
            return [];
        }

        if (self::userHasAnyRole($user, ['admin', 'college_admin', 'director'])) {
            return [
                'employee',
                'department_admin',
                'storekeeper',
                'programmer',
                'store_incharge',
                'd4_seat',
            ];
        }

        if (self::userHasRole($user, 'department_admin')) {
            return [
                'employee',
                'storekeeper',
                'programmer',
            ];
        }

        return [];
    }

    public static function roleOptions($employee = null, $user = null)
    {
        $allowed = self::allowedAssignableRoles($employee, $user);
        $options = [];

        if (\Schema::hasTable('roles')) {
            $roles = \DB::table('roles')
                ->where(function ($q) use ($allowed) {
                    $q->whereIn('slug', $allowed)->orWhereIn('name', $allowed);
                })
                ->orderBy('display_name')
                ->get();

            foreach ($roles as $role) {
                $slug = isset($role->slug) && $role->slug ? $role->slug : $role->name;
                $label = isset($role->display_name) && $role->display_name ? $role->display_name : ucwords(str_replace('_', ' ', $slug));
                $options[$slug] = $label;
            }
        }

        foreach ($allowed as $slug) {
            if (!isset($options[$slug])) {
                $options[$slug] = ucwords(str_replace('_', ' ', $slug));
            }
        }

        return $options;
    }

    public static function colleges($user = null)
    {
        $user = self::currentUser($user);

        if (!\Schema::hasTable('colleges')) {
            return collect([]);
        }

        $query = \DB::table('colleges');

        if (\Schema::hasColumn('colleges', 'is_active')) {
            $query->where('is_active', 1);
        }

        if (!$user) {
            return collect([]);
        }

        if (!self::isSuperuser($user) && self::collegeId($user)) {
            $query->where('id', self::collegeId($user));
        }

        return $query->orderBy('name')->get();
    }

    public static function departments($collegeId = null, $user = null)
    {
        $user = self::currentUser($user);

        if (!\Schema::hasTable('departments')) {
            return collect([]);
        }

        $query = \DB::table('departments');

        if (\Schema::hasColumn('departments', 'is_active')) {
            $query->where('is_active', 1);
        }

        if ($collegeId) {
            $query->where('college_id', $collegeId);
        }

        if (!$user) {
            return collect([]);
        }

        if (!self::isSuperuser($user)) {
            if (self::userHasRole($user, 'department_admin') && self::departmentId($user)) {
                $query->where('id', self::departmentId($user));
            } elseif (self::collegeId($user)) {
                $query->where('college_id', self::collegeId($user));
            } else {
                $query->whereRaw('1 = 0');
            }
        }

        return $query->orderBy('name')->get();
    }

    public static function transferDestinationColleges($user = null)
    {
        if (!\Schema::hasTable('colleges')) {
            return collect([]);
        }

        $query = \DB::table('colleges');

        if (\Schema::hasColumn('colleges', 'is_active')) {
            $query->where('is_active', 1);
        }

        return $query->orderBy('name')->get();
    }

    public static function transferDestinationDepartments($collegeId = null, $user = null)
    {
        if (!\Schema::hasTable('departments')) {
            return collect([]);
        }

        $query = \DB::table('departments');

        if ($collegeId) {
            $query->where('college_id', $collegeId);
        }

        if (\Schema::hasColumn('departments', 'is_active')) {
            $query->where('is_active', 1);
        }

        return $query->orderBy('name')->get();
    }

    public static function scopeLabel($user = null)
    {
        $user = self::currentUser($user);

        if (!$user) {
            return 'Scope: Not logged in';
        }

        if (self::isSuperuser($user)) {
            return 'Scope: All PAU / University';
        }

        $collegeName = 'Assigned College / Directorate';
        $departmentName = 'Assigned Department';

        $college = self::college($user);
        if ($college && isset($college->name)) {
            $collegeName = $college->name;
        }

        $department = self::department($user);
        if ($department && isset($department->name)) {
            $departmentName = $department->name;
            if (isset($department->place) && $department->place) {
                $departmentName .= ' - '.$department->place;
            }
        }

        if (self::userHasAnyRole($user, ['admin', 'college_admin', 'director'])) {
            return 'Scope: '.$collegeName;
        }

        if (self::userHasRole($user, 'department_admin')) {
            return 'Scope: '.$collegeName.' / '.$departmentName;
        }

        if (self::userHasAnyRole($user, ['storekeeper', 'programmer', 'store_incharge', 'd4_seat'])) {
            return 'Functional Scope: '.$collegeName.' / '.$departmentName;
        }

        return 'Scope: Own employee record only';
    }
}
