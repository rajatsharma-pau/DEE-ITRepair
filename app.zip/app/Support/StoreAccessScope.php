<?php

namespace App\Support;

use Illuminate\Database\Eloquent\Builder;

class StoreAccessScope
{
    public static function user($user = null)
    {
        return $user ?: auth()->user();
    }

    public static function hasRole($user, $role)
    {
        if (!$user) {
            return false;
        }

        if (method_exists($user, 'hasRole')) {
            return $user->hasRole($role);
        }

        if (isset($user->role)) {
            return $user->role === $role;
        }

        return false;
    }

    public static function hasAnyRole($user, array $roles)
    {
        if (!$user) {
            return false;
        }

        if (method_exists($user, 'hasAnyRole')) {
            return $user->hasAnyRole($roles);
        }

        foreach ($roles as $role) {
            if (self::hasRole($user, $role)) {
                return true;
            }
        }

        return false;
    }

    public static function isSuperuser($user = null)
    {
        $user = self::user($user);
        return self::hasRole($user, 'superuser');
    }

    public static function canViewStore($user = null)
    {
        $user = self::user($user);

        return self::hasAnyRole($user, array(
            'superuser',
            'storekeeper',
            'admin',
            'college_admin',
            'department_admin',
            'director',
        ));
    }

    public static function canManageStore($user = null)
    {
        $user = self::user($user);

        return self::hasAnyRole($user, array(
            'superuser',
            'storekeeper',
        ));
    }

    public static function collegeId($user = null)
    {
        $user = self::user($user);

        if (!$user) {
            return null;
        }

        if (isset($user->college_id) && $user->college_id) {
            return $user->college_id;
        }

        try {
            $employee = null;

            if (method_exists($user, 'employee')) {
                $employee = $user->employee;
            } elseif (isset($user->employee)) {
                $employee = $user->employee;
            }

            if ($employee && isset($employee->college_id) && $employee->college_id) {
                return $employee->college_id;
            }
        } catch (\Exception $e) {
            return null;
        }

        return null;
    }

    public static function departmentId($user = null)
    {
        $user = self::user($user);

        if (!$user) {
            return null;
        }

        if (isset($user->department_id) && $user->department_id) {
            return $user->department_id;
        }

        try {
            $employee = null;

            if (method_exists($user, 'employee')) {
                $employee = $user->employee;
            } elseif (isset($user->employee)) {
                $employee = $user->employee;
            }

            if ($employee && isset($employee->department_id) && $employee->department_id) {
                return $employee->department_id;
            }
        } catch (\Exception $e) {
            return null;
        }

        return null;
    }

    public static function collegeName($user = null)
    {
        $user = self::user($user);
        $collegeId = self::collegeId($user);

        if (!$collegeId) {
            return '';
        }

        try {
            $college = \DB::table('colleges')->where('id', $collegeId)->first();
            return $college ? $college->name : '';
        } catch (\Exception $e) {
            return '';
        }
    }

    public static function departmentName($user = null)
    {
        $user = self::user($user);
        $departmentId = self::departmentId($user);

        if (!$departmentId) {
            return '';
        }

        try {
            $department = \DB::table('departments')->where('id', $departmentId)->first();
            if (!$department) {
                return '';
            }

            $name = $department->name;
            if (isset($department->place) && $department->place) {
                $name .= ' - '.$department->place;
            }

            return $name;
        } catch (\Exception $e) {
            return '';
        }
    }

    public static function applyViewScope($query, $collegeColumn = 'college_id', $departmentColumn = 'department_id', $user = null)
    {
        $user = self::user($user);

        if (!$user) {
            return $query->whereRaw('1 = 0');
        }

        if (self::isSuperuser($user)) {
            return $query;
        }

        $collegeId = self::collegeId($user);
        $departmentId = self::departmentId($user);

        if (self::hasRole($user, 'department_admin') || self::hasRole($user, 'storekeeper')) {
            if ($departmentId) {
                return $query->where($departmentColumn, $departmentId);
            }

            return $query->whereRaw('1 = 0');
        }

        if (self::hasAnyRole($user, array('admin', 'college_admin', 'director'))) {
            if ($collegeId) {
                return $query->where($collegeColumn, $collegeId);
            }

            return $query->whereRaw('1 = 0');
        }

        return $query->whereRaw('1 = 0');
    }

    public static function forceManageScopeData(array $data, $user = null)
    {
        $user = self::user($user);

        if (!self::canManageStore($user)) {
            abort(403, 'Only Storekeeper can add/edit store records.');
        }

        if (self::isSuperuser($user)) {
            return $data;
        }

        $collegeId = self::collegeId($user);
        $departmentId = self::departmentId($user);

        if (!$collegeId || !$departmentId) {
            abort(403, 'Your login has no college/department assigned. Please update users.college_id and users.department_id.');
        }

        $data['college_id'] = $collegeId;
        $data['department_id'] = $departmentId;

        return $data;
    }

    public static function canManageRow($row, $user = null)
    {
        $user = self::user($user);

        if (!self::canManageStore($user)) {
            return false;
        }

        if (self::isSuperuser($user)) {
            return true;
        }

        return (int) $row->department_id === (int) self::departmentId($user)
            && (int) $row->college_id === (int) self::collegeId($user);
    }
}
